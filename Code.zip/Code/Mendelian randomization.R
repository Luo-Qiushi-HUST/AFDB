library(dplyr)
library(data.table)
library(vroom)
library(VariantAnnotation)
library(gwasvcf)
library(gwasglue)
library(ieugwasr)
library(plinkbinr)
library(TwoSampleMR)
library(MRPRESSO)
rm(list = ls())
gc()
setwd("C:/博士论文")

usethis::edit_r_environ()

api_status() #可查看当前API状态

#在线读取暴露与结局数据
exposure_dat = extract_instruments(outcomes = "ebi-a-GCST006414", p1 = 5e-08, clump = T, r2 = 0.001, kb = 10000)
outcome_dat = extract_outcome_data(snps = exposure_dat$SNP, outcomes = "ebi-a-GCST009541")
exposure_dat$id.exposure = "Atrial fibrillation"
outcome_dat$id.outcome = "Heart failure"

#数据准备
mr_data = harmonise_data(exposure_dat = exposure_dat,
                         outcome_dat = outcome_dat,
                         action = 2)   #去除回文序列，2去除，1不去除
write.csv(mr_data, file = "data/mr_data.csv")

#MR分析
res = mr(mr_data)
mr_method_list()
res_1 = mr(mr_data, method_list = c("mr_ivw","mr_simple_mode"))

#异质性检验
het = mr_heterogeneity(mr_data)
#异质性可视化
sin = mr_singlesnp(mr_data)
pdf(file = "异质性检测.pdf", width=10, heigh=8)
mr_funnel_plot(singlesnp_results = sin)
dev.off()

#MR-PRESSO异常值检测
presso = mr_presso(BetaOutcome ="beta.outcome",
                   BetaExposure = "beta.exposure",
                   SdOutcome ="se.outcome",
                   SdExposure = "se.exposure",
                   OUTLIERtest = TRUE,
                   DISTORTIONtest = TRUE,
                   data = mr_data,
                   NbDistribution = 1000,
                   SignifThreshold = 0.05)
presso$`MR-PRESSO results`$`Distortion Test`$`Outliers Indices` #如果显示NULL，则表示不存在异常值
mr_data_clean = mr_data[-c(84,136,159,172,255),]

#去除离群值
#rs = sin$SNP[sin$b < -3|sin$b > 3] #找到离群的SNP
#mr_data_clean = mr_data_finn[!mr_data_finn$SNP %in% rs,] #从原始数据框中移除这些SNP

het_clean = mr_heterogeneity(mr_data_clean) #异质性检验

#多效性检验
pleio = mr_pleiotropy_test(mr_data_clean)

#重新进行mr分析
res_clean = mr(mr_data_clean)
OR_clean = generate_odds_ratios(res_clean)
write.csv(OR_clean, "data/MRresult.csv")

#MR分析结果可视化
pdf(file = "MR.pdf", width=10, heigh=8)
mr_scatter_plot(res_clean, mr_data_clean)
dev.off()

#MR分析结果森林图
col = c("id.exposure", "id.outcome", "nsnp", "method", "or", "pval", "or_lci95", "or_uci95")
OR = OR_clean
OR = OR[,col]
OR$`OR (95% CI)` = sprintf("%.2f (%.2f to %.2f)", OR$or, OR$or_lci95, OR$or_uci95)
OR$pval = signif(OR$pval, 3)
#write.csv(OR, "OR.csv", row.names = F)
#OR = read.csv("OR.csv", header = T, check.names = F)
#OR$nsnp = ifelse(is.na(OR$nsnp), "", OR$nsnp)
OR$` ` = paste(rep(" ", 40), collapse = " ")
#绘制
library(forestploter)
library(grid)
pdf("MRresult_eQTLGen.pdf", width = 11, height = 7, onefile = FALSE)
tm = forest_theme(base_size = 10,   # 文本的大小
                  ci_pch = 16,      # 可信区间点的形状
                  ci_col = "black", # CI的颜色
                  ci_fill = "red",  # CI中se点的颜色填充
                  ci_alpha = 0.8,   # CI透明度
                  ci_lty = 1,       # CI的线型
                  ci_lwd = 1.5,     # CI的线宽
                  ci_Theight = 0.2, # CI的高度，默认是NULL
                  #参考线默认的参数，中间的竖的虚线
                  refline_lwd = 1,  # 中间的竖的虚线
                  refline_lty = "dashed",
                  refline_col = "grey20")
p = forest(OR[,c(1:4,10,6,9)],
           est = OR$or,         #效应值
           lower = OR$or_lci95, #置信区间下限
           upper = OR$or_uci95, #置信区间上限
           ci_column = 5,       #在哪一列画森林图，选空的那一列
           ref_line = 1,        #参考线位置
           xlim = c(-1, 3),      #设置轴范围
           ticks_at = c(0, 1, 2, 3),#设置刻度
           theme = tm)
edit_plot(p,
          which = "background",
          row = c(3),
          gp = gpar(fill = "lightsteelblue1"))
dev.off()

#SNP森林图
res_single = mr_singlesnp(mr_data_clean)
#绘制SNP森林图
pdf(file = "森林图.pdf", width = 9, heigh = 8)
mr_forest_plot(res_single)
dev.off()

#leave-one-out analysis(留一法分析)
pdf(file = "leave-one-out.pdf", width = 9, heigh = 8)
mr_leaveoneout_plot(leaveoneout_results = mr_leaveoneout(mr_data_clean))
dev.off()
