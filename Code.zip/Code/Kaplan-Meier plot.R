# 加载工作路径 ------------------------------------------------------------------
setwd("C:\\博士论文")
library(readxl)
library("survival")
library("survminer") 

data=read_xlsx("zstat_data-整理后-1943.xlsx")
fit <- survfit(Surv(Survival.Time,Mortality.status) ~ Group,data = data) #time是生存时间，status是0/1（死亡），data为数据集

ggsurvplot(
  fit, ## survfit返回的对象
  data=data,
  title="KM Curve",#标题
  axes.offset=TRUE,#坐标轴原点是否交叉
  pval=T,#p-value
  pval.method = T, # 是否展示P值的检验方法
  legend.title='', # 自定义图例的标题
  legend.labs=c('High Risk','Low risk'), # 自定义分组变量的名字
  conf.int = T, ##是否展示曲线的置信区间
  conf.int.style="ribbon",#可定义的类别包括("ribbon", "step")
  conf.int.alpha=0.1,
  xlab = 'Time (Years)', ## 自定义X轴的label
  ylab='Survival Pro',
  break.time.by = 6, ## X轴上的时间以多少步长而隔开(如果年为单位的话，一般设置为1就行了)
  risk.table = T, ## 所有可用的value是TRUE, FALSE, 'absolute', 'percentage', 'nrisk_cumcensor', 'nrisk_cumevents' 
  surv.plot.height=0.7,#生存图占图片比例
  risk.table.y.text.col = F, ## risk table左侧是否用对应分层变量的颜色注释
  risk.table.y.text = T, ## 是否展示分层变量的文本，如果不展示，则用颜色条进行展示
  surv.median.line = "hv", # 指出中位生存率
  palette = c("#1F78B4","#E31A1C"), ## 自定义曲线的颜色"#ff8c00"
  ncensor.plot = F, ## 是否展示censor table: 展示在时间t，删失对象的数目
)

####累积生存
ggsurvplot(fit,
           data = data,
           conf.int = TRUE, ######置信区间
           palette =c("indianred1", "#2E9FDF"),
           surv.median.line = "hv",######生存中线
           ggtheme = theme_bw(), 
           risk.table = T,#####下方具体表格
           pval=T,
           fun = "event")
