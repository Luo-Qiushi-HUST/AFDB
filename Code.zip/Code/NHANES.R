#*************                 *************

#### 0.准备好环境 ####
library(gtsummary)
library(survey)
library(haven)
library(tableone)
library(plyr)
library(dplyr) 
library(tidyverse)
library(arsenal) 

#读取路径

#### 一. 定位数据模块和变量，获取源数据 ####
##### 1.1 DEMO-人口学数据提取 ####
demo.d <- read_xpt("2005-2006/Demographics/demo_d.xpt")#参见上述设置默认路径，文件名称后缀不同"g,h"
demo.e <- read_xpt("2007-2008/Demographics/demo_e.xpt")#参见上述设置默认路径，文件名称后缀不同"g,h"
demo.f <- read_xpt("2009-2010/Demographics/demo_f.xpt")#参见上述设置默认路径，文件名称后缀不同"g,h"
demo.g <- read_xpt("2011-2012/Demographics/demo_g.xpt")#参见上述设置默认路径，文件名称后缀不同"g,h"
demo.h <- read_xpt("2013-2014/Demographics/demo_h.xpt")#参见上述设置默认路径，文件名称后缀不同"g,h"
demo.i <- read_xpt("2015-2016/Demographics/demo_i.xpt")#参见上述设置默认路径，文件名称后缀不同"g,h"
demo.j <- read_xpt("2017-2018/Demographics/demo_j.xpt")#参见上述设置默认路径，文件名称后缀不同"g,h"

### 提取研究所需要的变量并对变量进行重命名
# 年龄-RIDAGEYR; 性别-RIAGENDR; 种族-RIDRETH1; 教育程度-DMDEDUC2; 贫困程度-INDFMPIR;
demo.data.file <- dplyr::bind_rows(list(demo.d, demo.e,demo.f, demo.g,demo.h, demo.i,demo.j))
demo.data <- demo.data.file[,c('SEQN', 'RIDAGEYR', 'RIAGENDR', 'RIDRETH1', 'DMDEDUC2', 'INDFMPIR',"DMDMARTL")]

demo.data<- rename(.data=demo.data ,Gender=RIAGENDR,Age=RIDAGEYR,Race=RIDRETH1,PIR=INDFMPIR,EDUcation2=DMDEDUC2,Marital=DMDMARTL)

#性别
demo.data$Gender <- factor(demo.data$Gender,levels = c(1,2),labels = c("Male","Female"))
#教育
demo.data$edu <- ifelse(demo.data$EDUcation2 ==1,1,
                   ifelse(demo.data$EDUcation2 ==2,2,
                          ifelse(demo.data$EDUcation2 %in% c(3,4,5),3,NA)))
demo.data$edu <- factor(demo.data$edu,levels = c(1,2,3),labels = c("<High school","Completed high school",">High school"))
#婚姻
table(demo.data$Marital,useNA = c("ifany"))
demo.data$Marital_new <- ifelse(demo.data$Marital %in% c(1,6),1,
                           ifelse(demo.data$Marital %in% c(2,3,4,5),2,NA))
table(demo.data$Marital_new,useNA = c("ifany"))
demo.data$Marital_new <- factor(demo.data$Marital_new,levels = c(1,2),labels = c("Married/Living with partner","Widowed/Divorced/Separated/Never married"))
#种族
table(demo.data$Race,useNA = c("ifany"))
demo.data$Race <- factor(demo.data$Race,
                    levels = c(1,2,3,4,5),
                    labels = c("Mexican American","Other Hispanic","Non-Hispanic White","Non-Hispanic Black","Other Race"))

##### 1.2 SMQ-吸烟数据提取 #####
### 1.1 提取 Component文件
smq.d <- read_xpt("2005-2006/Questionnaire/smq_d.xpt")
smq.e <- read_xpt("2007-2008/Questionnaire/smq_e.xpt")
smq.f <- read_xpt("2009-2010/Questionnaire/smq_f.xpt")
smq.g <- read_xpt("2011-2012/Questionnaire/smq_g.xpt")
smq.h <- read_xpt("2013-2014/Questionnaire/smq_h.xpt")
smq.i <- read_xpt("2015-2016/Questionnaire/smq_i.xpt")
smq.j <- read_xpt("2017-2018/Questionnaire/smq_j.xpt")

### 2. 提取研究所需要的变量
# 是否吸烟至少100支-SMQ020; 现在是否吸烟-SMQ040; 多久前开始戒烟-SMQ050Q;
# 多久前开始戒烟的时间单位（天、周、月、年）-SMQ050U;
smq.data.file <- dplyr::bind_rows(list(smq.d, smq.e, smq.f, smq.g, smq.h, smq.i, smq.j))
smq.data <- smq.data.file[,c('SEQN', 'SMQ020', 'SMQ040', 'SMQ050Q', 'SMQ050U')]


# 本次衍生采取常规简单的定义
# SMQ020:Smoked at least 100 cigarettes in life, 1:Yes, 2:No
# SMQ040:Do you now smoke cigarettes, 1:Every day, 2:Some days	

# 使用 dplyr 的 mutate 函数可以 Create, modify, and delete 列，下面使用 mutate 衍生 smoke group 变量
# 波浪号 ~ 前面是条件，后面是满足这个条件的取值
smq.data <- mutate(smq.data, smoke = case_when(
  SMQ020 == 2 ~ 'Never smoker',
  SMQ020 == 1 & SMQ040 == 3 ~ 'Former smoker',
  SMQ020 == 1 & SMQ040 <= 2 ~ 'Current smoker'
))


##### 1.3 ALQ-饮酒数据提取及整理 ######
### 1.提取 Component文件
alq.d <- read_xpt("2005-2006/Questionnaire/alq_d.xpt")
alq.e <- read_xpt("2007-2008/Questionnaire/alq_e.xpt")
alq.f <- read_xpt("2009-2010/Questionnaire/alq_f.xpt")
alq.g <- read_xpt("2011-2012/Questionnaire/alq_g.xpt")
alq.h <- read_xpt("2013-2014/Questionnaire/alq_h.xpt")
alq.i <- read_xpt("2015-2016/Questionnaire/alq_i.xpt")
alq.j <- read_xpt("2017-2018/Questionnaire/alq_j.xpt")

### 2.提取研究所需要的变量
# 每年至少喝12杯酒-ALQ101
# 一生中至少喝过12次酒-ALQ110；
# 过去12个月多久喝一次酒-ALQ120Q
# 过去12个月饮酒频率的单位（周，月，年）-ALQ120U;

alq.data.file <- dplyr::bind_rows(list(alq.d, alq.e, alq.f, alq.g, alq.h, alq.i, alq.j))
alq.data <- alq.data.file[,c('SEQN', 'ALQ101', 'ALQ110', 'ALQ120Q', 'ALQ120U')]
# 仅衍生有无饮酒
alq.data$drink <- ifelse(alq.data$ALQ101 == 1, "yes",
                                ifelse(alq.data$ALQ101 == 2, "no", NA))

# 查看转换后的分布
table(alq.data$drink, useNA = "ifany")


##### 1.4 BMX-BMI #####
### 1.提取 Component文件
bmx.d <- read_xpt("2005-2006/Examination/bmx_d.xpt")
bmx.e <- read_xpt("2007-2008/Examination/bmx_e.xpt")
bmx.f <- read_xpt("2009-2010/Examination/bmx_f.xpt")
bmx.g <- read_xpt("2011-2012/Examination/bmx_g.xpt")
bmx.h <- read_xpt("2013-2014/Examination/bmx_h.xpt")
bmx.i <- read_xpt("2015-2016/Examination/bmx_i.xpt")
bmx.j <- read_xpt("2017-2018/Examination/bmx_j.xpt")

### 2.提取研究所需要的变量 BMI-BMXBMI; 腰围-BMXWAIST
bmx.data.file <- dplyr::bind_rows(list(bmx.d, bmx.e, bmx.f, bmx.g, bmx.h, bmx.i, bmx.j))
bmx.data <- bmx.data.file[,c('SEQN', 'BMXBMI', 'BMXWAIST',"BMXWT","BMXHT")]

bmx.data$BMI <- ifelse(bmx.data$BMXBMI <18.5, 'Underweight(<18.5)',
                               ifelse(bmx.data$BMXBMI >=18.5 & bmx.data$BMXBMI < 25, 'Normal(18.5 to <25)',
                                      ifelse(bmx.data$BMXBMI >=25 & bmx.data$BMXBMI < 30, 'Overweight(25 to <30)',
                                             'Obese(30 or greater)')))
# 将腰围单位从厘米转换为米
bmx.data$WC_m <- bmx.data$BMXWAIST / 100

# 计算ABSI
bmx.data$ABSI <- bmx.data$WC_m / (bmx.data$BMXBMI^(2/3) * bmx.data$BMXHT^(1/2))

bmx.data$BRI <- 364.2 - 365.5 * sqrt(1 - (bmx.data$BMXWAIST / (2 * pi)) / (0.5 * (bmx.data$BMXHT / 100)))

# 计算CI
bmx.data$CI <- bmx.data$BMXWAIST / 100 / (0.109 * sqrt(bmx.data$BMXWT / bmx.data$BMXHT))

# 计算WWI
bmx.data$WWI <- bmx.data$BMXWAIST / sqrt(bmx.data$BMXWT)

# 计算WtHR
bmx.data$WtHR <- bmx.data$BMXWAIST / bmx.data$BMXHT

##### 1.5 糖尿病诊断  #####
diq.d <- read_xpt("2005-2006/Questionnaire/diq_d.xpt")
diq.e <- read_xpt("2007-2008/Questionnaire/diq_e.xpt")
diq.f <- read_xpt("2009-2010/Questionnaire/diq_f.xpt")
diq.g <- read_xpt("2011-2012/Questionnaire/diq_g.xpt")
diq.h <- read_xpt("2013-2014/Questionnaire/diq_h.xpt")
diq.i <- read_xpt("2015-2016/Questionnaire/diq_i.xpt")
diq.j <- read_xpt("2017-2018/Questionnaire/diq_j.xpt")
##是否有医生告知您患有糖尿病
diq.data.file <- dplyr::bind_rows(diq.d, diq.e, diq.f, diq.g, diq.h, diq.i, diq.j)
diq.data <- diq.data.file[,c('SEQN','DIQ010')]
diq.data$diabetes <- ifelse(diq.data$DIQ010 == 1, "yes",
                         ifelse(diq.data$DIQ010 == 2, "no", NA))
table(alq.data$drink, useNA = "ifany")

##### 1.6 高密度脂蛋白 低密度脂蛋白 胆固醇 #####
hdl.d <- read_xpt("2005-2006/Laboratory/hdl_d.xpt")
hdl.e <- read_xpt("2007-2008/Laboratory/hdl_e.xpt")
hdl.f <- read_xpt("2009-2010/Laboratory/hdl_f.xpt")
hdl.g <- read_xpt("2011-2012/Laboratory/hdl_g.xpt")
hdl.h <- read_xpt("2013-2014/Laboratory/hdl_h.xpt")
hdl.i <- read_xpt("2015-2016/Laboratory/hdl_i.xpt")
hdl.j <- read_xpt("2017-2018/Laboratory/hdl_j.xpt")

hdl.data.file <- dplyr::bind_rows(hdl.d, hdl.e, hdl.f, hdl.g, hdl.h, hdl.i, hdl.j)
hdl.data <- hdl.data.file[,c('SEQN', "LBDHDD")]

trigly.d <- read_xpt("2005-2006/Laboratory/trigly_d.xpt")
trigly.e <- read_xpt("2007-2008/Laboratory/trigly_e.xpt")
trigly.f <- read_xpt("2009-2010/Laboratory/trigly_f.xpt")
trigly.g <- read_xpt("2011-2012/Laboratory/trigly_g.xpt")
trigly.h <- read_xpt("2013-2014/Laboratory/trigly_h.xpt")
trigly.i <- read_xpt("2015-2016/Laboratory/trigly_i.xpt")
trigly.j <- read_xpt("2017-2018/Laboratory/trigly_j.xpt")
trigly.data.file <- dplyr::bind_rows(list(trigly.d, trigly.e, trigly.f, trigly.g, trigly.h, trigly.i, trigly.j))
trigly.data <- trigly.data.file[, c("SEQN", "LBDLDL","LBXTR")]  



##### 1.7 心衰 脑卒中 冠心病  #####
# 心衰-MCQ160B; 冠心病-MCQ160C; 脑卒中-MCQ160F;
mcq.d <- read_xpt("2005-2006/Questionnaire/mcq_d.xpt")
mcq.e <- read_xpt("2007-2008/Questionnaire/mcq_e.xpt")
mcq.f <- read_xpt("2009-2010/Questionnaire/mcq_f.xpt")
mcq.g <- read_xpt("2011-2012/Questionnaire/mcq_g.xpt")
mcq.h <- read_xpt("2013-2014/Questionnaire/mcq_h.xpt")
mcq.i <- read_xpt("2015-2016/Questionnaire/mcq_i.xpt")
mcq.j <- read_xpt("2017-2018/Questionnaire/mcq_j.xpt")

mcq.data.file <- dplyr::bind_rows(list(mcq.d, mcq.e, mcq.f, mcq.g, mcq.h, mcq.i, mcq.j))

mcq.data <- mcq.data.file[,c("SEQN", "MCQ160B","MCQ160C", "MCQ160F")]

##### 1.8 BPQ-血压数据提取 #####
bpq.d <- read_xpt("2005-2006/Questionnaire/bpq_d.xpt")
bpq.e <- read_xpt("2007-2008/Questionnaire/bpq_e.xpt")
bpq.f <- read_xpt("2009-2010/Questionnaire/bpq_f.xpt")
bpq.g <- read_xpt("2011-2012/Questionnaire/bpq_g.xpt")
bpq.h <- read_xpt("2013-2014/Questionnaire/bpq_h.xpt")
bpq.i <- read_xpt("2015-2016/Questionnaire/bpq_i.xpt")
bpq.j <- read_xpt("2017-2018/Questionnaire/bpq_j.xpt")

# 高血压诊断-BPQ020;
bpq.data.file <- dplyr::bind_rows(list(bpq.d, bpq.e, bpq.f, bpq.g, bpq.h, bpq.i, bpq.j))
bpq.data <- bpq.data.file[,c("SEQN", "BPQ020")]
bpq.data$Hbp <- ifelse(bpq.data$BPQ020 == 1, "yes",
                            ifelse(bpq.data$BPQ020 == 2, "no", NA))
table(bpq.data$Hbp, useNA = "ifany")

##### 1.9 PHQ-9 抑郁数据的提取 #####
dpq.d <- read_xpt("2005-2006/Questionnaire/dpq_d.xpt")
dpq.e <- read_xpt("2007-2008/Questionnaire/dpq_e.xpt")
dpq.f <- read_xpt("2009-2010/Questionnaire/dpq_f.xpt")
dpq.g <- read_xpt("2011-2012/Questionnaire/dpq_g.xpt")
dpq.h <- read_xpt("2013-2014/Questionnaire/dpq_h.xpt")
dpq.i <- read_xpt("2015-2016/Questionnaire/dpq_i.xpt")
dpq.j <- read_xpt("2017-2018/Questionnaire/dpq_j.xpt")

dpq.data.file <- dplyr::bind_rows(list(dpq.d, dpq.e, dpq.f, dpq.g, dpq.h, dpq.i, dpq.j))
dpq.data <- dpq.data.file[, c("SEQN","DPQ010","DPQ020","DPQ030","DPQ040","DPQ050","DPQ060","DPQ070","DPQ080","DPQ090")]

##### 1.10总卡路里数据提取(第1天 & 第2天) #####
# 第1天
dr1tot.d <- read_xpt('2005-2006/Dietary/dr1tot_d.xpt')
dr1tot.e <- read_xpt('2007-2008/Dietary/dr1tot_e.xpt')
dr1tot.f <- read_xpt('2009-2010/Dietary/dr1tot_f.xpt')
dr1tot.g <- read_xpt('2011-2012/Dietary/dr1tot_g.xpt')
dr1tot.h <- read_xpt('2013-2014/Dietary/dr1tot_h.xpt')
dr1tot.i <- read_xpt('2015-2016/Dietary/dr1tot_i.xpt')
dr1tot.j <- read_xpt('2017-2018/Dietary/dr1tot_j.xpt')

dr1tot.data.file <- dplyr::bind_rows(list(dr1tot.d, dr1tot.e, dr1tot.f, dr1tot.g, dr1tot.h, dr1tot.i, dr1tot.j))
dr1tot.data <- dr1tot.data.file[,c('SEQN', 'DR1TLZ', 'DR1TKCAL')]

# 第2天
dr2tot.d <- read_xpt('2005-2006/Dietary/dr2tot_d.xpt')
dr2tot.e <- read_xpt('2007-2008/Dietary/dr2tot_e.xpt')
dr2tot.f <- read_xpt('2009-2010/Dietary/dr2tot_f.xpt')
dr2tot.g <- read_xpt('2011-2012/Dietary/dr2tot_g.xpt')
dr2tot.h <- read_xpt('2013-2014/Dietary/dr2tot_h.xpt')
dr2tot.i <- read_xpt('2015-2016/Dietary/dr2tot_i.xpt')
dr2tot.j <- read_xpt('2017-2018/Dietary/dr2tot_j.xpt')

dr2tot.data.file <- dplyr::bind_rows(list(dr2tot.d, dr2tot.e, dr2tot.f, dr2tot.g, dr2tot.h, dr2tot.i, dr2tot.j))

dr2tot.data <- dr2tot.data.file[,c('SEQN', 'DR2TLZ', 'DR2TKCAL')]

# 合并第1天&第2天的变量
dr.data <- merge(dr2tot.data, dr1tot.data)

##### 1.11 ABPI 指数 #####    ABPI（踝臂脉搏指数，Ankle-Brachial Pressure Index）
#数据年份2001-2004年
# 加载2001-2002年和2003-2004年的ABPI数据
abpi_b <- read_xpt('2001-2002/Examination/LEXAB_B.xpt')
abpi_c <- read_xpt('2003-2004/Examination/LEXAB_C.xpt')

# 将数据结合到一起
abpi_data.file<- dplyr::bind_rows(list(abpi_b, abpi_c))
ABPI.data <- abpi_data.file[,c('SEQN', 'LEXLABPI', 'LEXRABPI')]
# 查看加载的ABPI数据，之后根据文献判断ABPI
head(abpi_data)



##### 1.12 AIP #####   新型脂质代谢标志物血浆动脉粥样硬化指数 （AIP）、内脏肥胖指数 （VAI） 和脂质积累产物 （LAP）。
#（动脉粥样硬化指数，Atherogenic Index of Plasma）: 
#是一种反映血脂代谢状态的指标，由血脂水平（通常是甘油三酯与高密度脂蛋白的比值）计算，较高的AIP值通常与更高的心血管疾病风险相关。
#AIP=log(TG/HDL−C)


##### 1.13 BARD#####
#（肝纤维化评分，BARD Score）:
#是一种非侵入性的评分系统，用于估计非酒精性脂肪性肝病患者发生肝纤维化的风险。
#BARD评分的组成：
#BMI ≥ 28: 如果BMI大于或等于28分，记1分。
#AST/ALT比值 ≥ 0.8: 如果AST与ALT的比值大于或等于0.8，记2分。
#糖尿病：如果患有糖尿病，记1分。
#BARD评分的总分：
#BARD评分的总分为0到4分，评分越高，表示患者患有肝纤维化的风险越高。#评分标准：0-1分：低肝纤维化风险。2-4分：较高肝纤维化风险。

df$BARD <- with(df, 
                ifelse(BMI >= 28, 1, 0) +                   # BMI ≥ 28 计1分
                  ifelse(AST / ALT >= 0.8, 2, 0) +           # AST/ALT比值 ≥ 0.8 计2分
                  ifelse(Diabetes == 1, 1, 0)                # 有糖尿病计1分
)




#####1.14FIB-4##### 
#（纤维化指数，Fibrosis Index）:
# 常用于评估肝纤维化的非侵入性评分，基于一系列实验室指标计算得出。
# Age: 年龄
# AST: 天冬氨酸氨基转移酶（U/L）
# ALT: 丙氨酸氨基转移酶（U/L）
# Platelet: 血小板计数（10^9/L）

# 计算FIB-4评分
df$FIB4 <- (df$Age * df$AST) / (df$Platelet * sqrt(df$ALT))

#APRI评分计算：
# AST: 天冬氨酸氨基转移酶（U/L）
# AST_ULN: 天冬氨酸氨基转移酶的正常上限（通常为40 U/L）
# Platelet: 血小板计数（10^9/L）

# 计算APRI评分
df$APRI <- ((df$AST / df$AST_ULN) * 100) / df$Platelet
##NAFLD纤维化评分（NAFLD Fibrosis Score） 
# Age: 年龄
# BMI: 体重指数
# Diabetes: 糖尿病或空腹血糖受损（1=有, 0=无）
# AST: 天冬氨酸氨基转移酶（U/L）
# ALT: 丙氨酸氨基转移酶（U/L）
# Platelet: 血小板计数（10^9/L）
# Albumin: 血清白蛋白（g/dL）

# 计算NAFLD纤维化评分
df$NAFLD_Fibrosis_Score <- -1.675 + 
  (0.037 * df$Age) + 
  (0.094 * df$BMI) + 
  (1.13 * df$Diabetes) + 
  (0.99 * (df$AST / df$ALT)) - 
  (0.013 * df$Platelet) - 
  (0.66 * df$Albumin)


#####1.15FLI##### 
#（脂肪肝指数，Fatty Liver Index）
#: 结合体重、BMI、腰围和血脂水平等指标，主要用于评估脂肪肝的可能性。
#FLI评分解释：FLI < 30：脂肪肝风险较低。FLI 30 - 60：中等脂肪肝风险。FLI > 60：高度怀疑有脂肪肝。
# TG: 甘油三酯（mg/dL）# BMI: 体重指数（kg/m²）# Waist: 腰围（cm）# ALT: 谷丙转氨酶（U/L）
# 计算FLI
df$FLI <- (exp(0.953 * log(df$TG) + 0.139 * df$BMI + 0.718 * log(df$ALT) + 0.053 * df$Waist - 15.745) / 
             (1 + exp(0.953 * log(df$TG) + 0.139 * df$BMI + 0.718 * log(df$ALT) + 0.053 * df$Waist - 15.745))) * 100


#####1.16GNRI#####
#（简易营养风险指数，Geriatric Nutritional Risk Index）
#: 用于评估老年患者的营养风险，考虑了血清白蛋白水平、体重和身高。
# Albumin: 血清白蛋白（g/dL）# Weight: 实际体重（kg）# Height: 身高（m）# Sex: 性别（"M"表示男性，"F"表示女性）

# 计算理想体重
df$Ideal_Weight <- ifelse(df$Sex == "M", 22 * (df$Height^2), 22 * (df$Height^2))
# 计算GNRI
df$GNRI <- (1.489 * df$Albumin) + (41.7 * (df$Weight / df$Ideal_Weight))

#####1.17GPS#####
#（格拉斯哥预后评分，Glasgow Prognostic Score）
#  一种基于C反应蛋白和白蛋白水平的炎症状态评分，常用于评估癌症等慢性疾病患者的预后情况。
# CRP: C反应蛋白水平（mg/L）
# Albumin: 血清白蛋白水平（g/dL）
# 计算GPS评分
df$GPS <- with(df, ifelse(CRP > 10 & Albumin < 3.5, 2,
                          ifelse(CRP > 10 & Albumin >= 3.5, 1, 0)))

####DII的基本计算步骤####
#①营养成分摄入量：收集个体每日摄入的各类营养成分数据。
#②标准化处理：将这些营养成分的摄入量与全球平均值进行标准化处理。
#③赋权分数：每种成分根据其对炎症的影响（抗炎或促炎）赋予不同的权重。
#④总分计算：将各成分的标准化摄入量与权重相乘，然后求和得出DII总分












#### 2 提取分析相关变量####
##### 2.1 权重变量 ##### 
# 找到权重变量
# DEMO->MEC-Dietary->MEC-CFQ
# 饮食中的权重：https://wwwn.cdc.gov/nchs/nhanes/2013-2014/DR1TOT_H.htm

# SMQ: https://wwwn.cdc.gov/Nchs/Nhanes/2013-2014/SMQ_H.htm
# SMQ 中没有权重信息：The NHANES full sample 2-Year MEC Exam Weights (WTMEC2YR) should be used to analyze the 2013-14 SMQ variables in conjunction with the laboratory measurements on tobacco exposure or other examination measurements.

# CFQ: https://wwwn.cdc.gov/Nchs/Nhanes/2011-2012/CFQ_G.htm
# CFQ 中没有权重信息：MEC exam sample weights should be used for the analyses 
# and are available on the NHANES website 

weight.data <- demo.data.file[,c('SEQN', 'WTMEC2YR')]
weight.data$WTMEC14YR <- weight.data$WTMEC2YR/7 #权重的计算方式，需要按 Cycle 进行平均

##### 2.2 复杂抽样的其他变量-DEMO #####
survey.design.data <- demo.data.file[,c('SEQN', 'SDMVPSU', 'SDMVSTRA')]

#### 3.合并上述所有数据（把列拼接起来）-Output #### 
#导入DII数据
dat000=read.csv(file = "DII.csv")
dat000$SEQN=dat000$seqn
##### 3.1 合并步骤1 & 2中提取的数据 #####
# 合并所有步骤中的数据集
output <- plyr::join_all(list(demo.data,              #1.1人口数据
                              smq.data,               #1.2吸烟数据
                              alq.data,               #1.3饮酒数据
                              bmx.data,               #1.4 BMI
                              diq.data,               #1.5糖尿病数据
                              hdl.data,trigly.data,   #1.6高密度脂蛋白数据，胆固醇数据
                              mcq.data,               #1.7心衰、卒中、冠心病
                              bpq.data,               #1.8高血压
                              dpq.data,               #1.9抑郁数据
                              dr.data,                #1.10能量数据
                              weight.data,            #权重
                              survey.design.data,     #
                              dat000),                #DII
                              by = 'SEQN', type = 'left')

##### 3.2 针对合并后的数据进行质控，确定人数能对得上 #####
dim(output) # 70190   ✅
# 1.根据 Table1 进行质纳入排除
data.age.20 <- subset.data.frame(output, Age >= 20 )
dim(data.age.20) # 39749   ✅ 3
70190-39749                              #30441
data.age.20.WWI <- subset.data.frame(output, Age >= 20 &
                                   (!is.na(WWI)) )
dim(data.age.20.WWI) # 35843  ✅       3906 #
39749-35843
data.age.20.WWI.PHQ9 <- subset.data.frame(output, Age >= 20 &
                                       (!is.na(WWI))&
                                       output$DPQ010 %in% c(0,1,2,3) & 
                                       output$DPQ020 %in% c(0,1,2,3) & 
                                       output$DPQ030 %in% c(0,1,2,3) & 
                                       output$DPQ040 %in% c(0,1,2,3) & 
                                       output$DPQ050 %in% c(0,1,2,3) & 
                                       output$DPQ060 %in% c(0,1,2,3) & 
                                       output$DPQ070 %in% c(0,1,2,3) & 
                                       output$DPQ080 %in% c(0,1,2,3) & 
                                       output$DPQ090 %in% c(0,1,2,3))
dim(data.age.20.WWI.PHQ9) # 32986  ✅   2857

35843-32986  
data.age.20.WWI.PHQ9.MCQ160F <- subset.data.frame(data.age.20.WWI.PHQ9,
                                          data.age.20.WWI.PHQ9$MCQ160F==1|data.age.20.WWI.PHQ9$MCQ160F==2)
dim(data.age.20.WWI.PHQ9.MCQ160F)   # 32946   ✅        
32986-32946
paper.data <- data.age.20.WWI.PHQ9.MCQ160F
write.csv(paper.data,"WWIandPSD - 副本/RAWdata.ABSI.csv",row.names = F)
# 2. 确认下权重
weight.non.na.index <- which(!is.na(data.age.20$WTMEC14YR))
sum(data.age.20$WTMEC14YR[weight.non.na.index]) # 计算权重224375768 ✅

##### 4 卒中后抑郁#####
paper.data$PHQ <- paper.data$DPQ010 + paper.data$DPQ020 + paper.data$DPQ030 +
  paper.data$DPQ040 + paper.data$DPQ050 + paper.data$DPQ060 + 
  paper.data$DPQ070 + paper.data$DPQ080 + paper.data$DPQ090

paper.data$PSD <- ifelse(paper.data$MCQ160F == 1 & paper.data$PHQ>=10, 1, 0)

##### 5.13 WWI  #暴露-WWI #####
# 四分位数
WWI_quartiles <- quantile(paper.data$WWI, probs = c(0.25, 0.5, 0.75), na.rm = TRUE)
# 查看四分位数
print(WWI_quartiles)
# 四个区间
paper.data$WWI_quartile <- cut(paper.data$WWI, breaks = c(-Inf, WWI_quartiles, Inf), labels = c("Q1", "Q2", "Q3", "Q4"))

#### 6.再次筛选 ####
# 根据全部的结果，去掉核心变量缺失的行
# there are 2796 participants who had information on cognitive
# performance and dietary L and Z intake (some missing supplement intake), and who had information on important covariates (sex, age, race/ethnicity, smoking, education).
paper.data <- subset.data.frame(paper.data, 
                                (!is.na(PSD)) & 
                                  (!is.na(WWI)) )
write.csv(paper.data,"WWIandPSD - 副本/paper.ABSIdata.csv",row.names = FALSE) 
                              
dim(paper.data) #32863   ✅
colnames(paper.data)
analyze.variable <- c("SEQN", "WTMEC14YR", "SDMVPSU", "SDMVSTRA",
                      "Gender", "PIR", "Age", "Race", "edu","Marital_new" ,
                      "Hbp" , "drink", "smoke", "BMI","diabetes",
                      "LBDHDD", "LBDLDL","LBXTR", 
                      "MCQ160B", "MCQ160C", "MCQ160F",
                      "PSD" ,"WWI_quartile"  ,"WWI")

paper.data <- paper.data[, analyze.variable]
paper.data<- rename(.data=paper.data,Marital=Marital_new,HDL=LBDHDD,LDL=LBDLDL,
                    TC=LBXTR,stroke=MCQ160F,HF=MCQ160B,CHD=MCQ160C)
write.csv(paper.data,"WWIandPSD - 副本/paper.ABSIdata.csv",row.names = FALSE)

#### 二、Paper Table ####
#### 1. 分析数据准备 ####
# 生成复杂抽样的对象
NHANES_design <- svydesign(data = paper.data, ids = ~SDMVPSU, strata = ~SDMVSTRA, nest = TRUE, weights = ~WTMEC14YR, survey.lonely.psu = "adjust") 

# 修饰表格1-修改分类变量取值出现的顺序

# 按照临床含义排序-1饮酒、吸烟
paper.data$BMI <- factor(paper.data$BMI, 
                               levels = c('Underweight(<18.5)', 
                                          'Normal(18.5 to <25)',
                                          'Overweight(25 to <30)',
                                          'Obese(30 or greater)'))

# 按照取值的顺序-Race
levels(fct_infreq(paper.data$Race)) # 从大到小的顺序
# levels(fct_rev(fct_infreq(paper.data$Race))) # 从小到大的顺序

paper.data$Race <- factor(paper.data$Race, levels(fct_infreq(paper.data$Race)))# 从大到小的顺序
# paper.data$Race <- factor(paper.data$Race, levels(fct_rev(fct_infreq(paper.data$Race))))# 从小到大的顺序

# 加权下的排序
svytotal(~ Race, NHANES_design, na.rm=TRUE) # 离散性变量

NHANES_design <- svydesign(data = paper.data, ids = ~SDMVPSU, strata = ~SDMVSTRA, nest = TRUE, weights = ~WTMEC14YR, survey.lonely.psu = "adjust") 

#### 2. Table1 ####
bl <- tbl_svysummary(
  data = NHANES_design,  
  by = WWI_quartile,
  include = c(Age, Gender, Race, edu, Marital,PIR ,BMI, stroke, drink, smoke, PSD, HDL, LDL, TC,HF,CHD,diabetes),
  label = list(Age ~ 'Age (years)', PIR ~ 'PIR'),
  statistic = list(
    all_continuous()  ~ "{median} ({p25}, {p75})", 
    all_categorical() ~ "{n_unweighted} ({p}%)"
  ),
  digits = list(Age ~ 1, PIR ~ 2),  
  sort = list(Race ~ "frequency", BMI ~ "alphanumeric"),
  missing = 'no'
)  %>% 
  add_overall() %>%
  add_p() %>%
  modify_header(
    stat_0 ~ "**Overall**" ,
    stat_1 ~ "**Q1**",
    stat_2 ~ "**Q2**",
    stat_3 ~ "**Q3**",
    stat_4 ~ "**Q4**",
    p.value ~ "**P Value**"  # 更新列标题
  ) %>%
  modify_spanning_header(
    update = c(stat_1, stat_2, stat_3, stat_4) ~ "**WWI**"
  ) %>%
  modify_footnote(
    update = all_stat_cols() ~ "median (IQR) for continuous; n (%) for categorical"
  ) %>%
  bold_labels() %>%
  bold_p(0.05)
# 打印结果
print(bl)
library(officer)
library(flextable)
# 将gtsummary表格转换为flextable对象
bl_flextable <- as_flex_table(bl)
# 调整表格格式
bl_flextable <- bl_flextable %>%
  set_table_properties(width = 1, layout = "autofit") %>%
  fontsize(size = 10, part = "all") %>%
  autofit()

# 创建一个Word文档并添加表格
doc <- read_docx() %>%
  body_add_flextable(bl_flextable) %>%
  body_add_par("WWIandPSD - 副本/Table 1: Summary of Characteristics by DII Quartile", style = "heading 1")

# 保存Word文档
print(doc, target = "WWIandPSD - 副本/table1ABSI.docx")

#### 2. Table2  #####
# 使用函数 tbl_regression，来一键生成结果
# no-adjusted
NHANES_design$variables$PSD <- as.integer(NHANES_design$variables$PSD)
m1 <- svyglm(PSD~ WWI_quartile, design = NHANES_design,family = binomial()) 
#tbl_regression(m1, exponentiate = TRUE)
tbl_m1 <- tbl_regression(m1, exponentiate = TRUE, include = c(WWI_quartile) )%>%
modify_header(label ~ "**Model 1**") # 修改列标题

# Partially adjusted
m2 <- svyglm(PSD~ WWI_quartile+ Age + Gender + Race, 
             design = NHANES_design,family = binomial())
#tbl_regression(m2, include = c(DII_quartile)) #只呈现 WWI_quartile
tbl_m2 <- tbl_regression(m2, exponentiate = TRUE, include = c(WWI_quartile)) %>% 
  modify_header(label ~ "**Model 2**") # 修改列标题
# Fully adjusted
m3 <- svyglm(PSD~ WWI_quartile+ Age + Gender + BMI +
               drink + smoke + PIR + edu+Race+CHD+HF+
               Marital+diabetes, 
             design = NHANES_design,family = binomial())
#tbl_regression(m3, include = c(DII_quartile)) # 只呈现 DII_quartile
tbl_m3 <- tbl_regression(m3, exponentiate = TRUE, include = c(WWI_quartile)) %>% 
  modify_header(label ~ "**Model 3**") # 修改列标题

combined_tbl <- tbl_merge(
  tbls = list(tbl_m1, tbl_m2, tbl_m3),
  tab_spanner = c("**No-adjusted**", "**Partially adjusted**", "**Fully adjusted**")
)
# 显示合并后的表格
combined_tbl
# 将合并后的表格转换为 flextable 对象
library(flextable)
combined_tbl_flex <- as_flex_table(combined_tbl)
# 保存为 Word 文档
save_as_docx(combined_tbl_flex, path = "WWIandPSD - 副本/combined_regression_results.docx")


#### 3. Fig2  #####
library(rms)
library(ggplot2)

ddist <- datadist(NHANES_design$variables)  # 这里 `NHANES_design$variables` 是你的数据框
options(datadist = "ddist")  # 设置全局选项
# 模型 1：不调整任何参数
fit1 <- rms::Glm(PSD ~ rcs(WWI, 4), family = binomial(), data = NHANES_design$variables)
# 模型 2：部分调整
fit2 <- rms::Glm(PSD ~ rcs(WWI, 4) + Age + Gender + Race, family = binomial(), data = NHANES_design$variables)
# 模型 3：完全调整
fit3 <- Glm(PSD ~ rcs(WWI, 4) + Age + Gender + BMI + drink + smoke + PIR + edu + Race + CHD + HF + Marital + diabetes, 
            family = binomial(), data = NHANES_design$variables)

# 模型 1：不调整任何参数
pred1 <- rms::Predict(fit1, WWI, type = "predictions", fun = exp, ref.zero = TRUE)

# 模型 2：部分调整
pred2 <- rms::Predict(fit2, WWI, type = "predictions", fun = exp, ref.zero = TRUE)

# 模型 3：完全调整
pred3 <- rms::Predict(fit3, WWI, type = "predictions", fun = exp, ref.zero = TRUE)

# 模型 1 图形
p1 <- ggplot() +
  geom_line(data = pred1, aes(x = WWI, y = yhat), linetype = 'solid', size = 1.2, color = 'red', alpha = 0.8) +
  geom_ribbon(data = pred1, aes(x = WWI, ymin = lower, ymax = upper), alpha = 0.2, fill = 'blue') +
  geom_hline(yintercept = 1, linetype = "dashed", color = "grey", size = 0.8) +
  scale_x_continuous('DII (Dietary Inflammatory Index)') +
  scale_y_continuous("Odds Ratio (95% CI)", limits = c(0, 7)) +
  labs(title = "Model 1: No Adjustment",
       subtitle = "Logistic regression with RCS, ref.zero = TRUE") +
  theme_bw() +
  theme(axis.line = element_line(color = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        axis.text = element_text(size = 12),
        axis.title = element_text(size = 14, face = "bold"),
        plot.title = element_text(size = 16, face = "bold", hjust = 0.5))

# 模型 2 图形
p2 <- ggplot() +
  geom_line(data = pred2, aes(x = WWI, y = yhat), linetype = 'solid', size = 1.2, color = 'red', alpha = 0.8) +
  geom_ribbon(data = pred2, aes(x = WWI, ymin = lower, ymax = upper), alpha = 0.2, fill = 'blue') +
  geom_hline(yintercept = 1, linetype = "dashed", color = "grey", size = 0.8) +
  scale_x_continuous('DII (Dietary Inflammatory Index)') +
  scale_y_continuous("Odds Ratio (95% CI)", limits = c(0, 7)) +
  labs(title = "Model 2: Partially Adjusted",
       subtitle = "Logistic regression with RCS, ref.zero = TRUE") +
  theme_bw() +
  theme(axis.line = element_line(color = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        axis.text = element_text(size = 12),
        axis.title = element_text(size = 14, face = "bold"),
        plot.title = element_text(size = 16, face = "bold", hjust = 0.5))

# 模型 3 图形
p3 <- ggplot() +
  geom_line(data = pred3, aes(x = WWI, y = yhat), linetype = 'solid', size = 1.2, color = 'red', alpha = 0.8) +
  geom_ribbon(data = pred3, aes(x = WWI, ymin = lower, ymax = upper), alpha = 0.2, fill = 'blue') +
  geom_hline(yintercept = 1, linetype = "dashed", color = "grey", size = 0.8) +
  scale_x_continuous('DII (Dietary Inflammatory Index)') +
  scale_y_continuous("Odds Ratio (95% CI)", limits = c(0, 7)) +
  labs(title = "Model 3: Fully Adjusted",
       subtitle = "Logistic regression with RCS, ref.zero = TRUE") +
  theme_bw() +
  theme(axis.line = element_line(color = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        axis.text = element_text(size = 12),
        axis.title = element_text(size = 14, face = "bold"),
        plot.title = element_text(size = 16, face = "bold", hjust = 0.5))
library(patchwork)

# 将三个图形并排展示
combined_plot <- p1 + p2 + p3 + plot_layout(ncol = 3)

# 显示并排图形
combined_plot


